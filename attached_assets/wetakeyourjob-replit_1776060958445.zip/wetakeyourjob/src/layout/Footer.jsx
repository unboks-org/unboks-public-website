import { NavLink } from 'react-router-dom';

const footerLinks = [
  { label: 'Services', href: '/services' },
  { label: 'About', href: '/about' },
  { label: 'Contact', href: '/contact' },
  { label: 'Login', href: '/login' },
];

export default function Footer() {
  return (
    <footer className="border-t border-slate-200 bg-[#f6f8fc] py-16">
      <div className="container-shell flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between">
        <div className="max-w-md">
          <p className="text-lg font-semibold text-slate-950">wetakeyourjob.com</p>
          <p className="mt-3 text-sm leading-7 text-slate-600">
            All your messages. 1 Inbox. Less busywork, faster replies, and more time for what
            matters.
          </p>
        </div>
        <div className="grid gap-8 sm:grid-cols-2">
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">Navigation</p>
            <div className="mt-3 flex flex-col gap-3">
              {footerLinks.map((link) => (
                <NavLink
                  key={link.href}
                  to={link.href}
                  className="text-sm text-slate-600 hover:text-slate-950"
                >
                  {link.label}
                </NavLink>
              ))}
            </div>
          </div>
          <div>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-slate-500">Contact</p>
            <div className="mt-3 space-y-3 text-sm text-slate-600">
              <p>hello@wetakeyourjob.com</p>
              <p>Get started when your team is ready for calmer communication.</p>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
