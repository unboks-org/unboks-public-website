import { Link } from 'react-router-dom';
import Seo from '../components/Seo';
import heroImage from '../assets/wtyj_panel_hero_main.png';
import oneInboxImage from '../assets/wtyj_panel_one_inbox_total_control.png';
import lessBusyworkImage from '../assets/wtyj_panel_less_busywork_more_business.png';
import fasterRepliesImage from '../assets/wtyj_panel_faster_replies.png';
import coverageImage from '../assets/wtyj_panel_24_7_coverage.png';
import allLanguagesImage from '../assets/wtyj_panel_all_languages.png';

const supportCards = [
  {
    title: 'One Inbox. Total Control.',
    image: oneInboxImage,
    alt: 'One inbox panel showing every channel in one system.',
    desktopSpan: 'xl:col-span-2',
  },
  {
    title: 'Less busywork. More business.',
    image: lessBusyworkImage,
    alt: 'Less busywork panel focused on more business and time back.',
    desktopSpan: 'xl:col-span-2',
  },
  {
    title: 'Faster replies. Happier clients.',
    image: fasterRepliesImage,
    alt: 'Faster replies panel showing a client conversation flow.',
    desktopSpan: 'xl:col-span-2',
  },
  {
    title: '24/7 coverage.',
    image: coverageImage,
    alt: '24/7 coverage panel with a clock illustration.',
    desktopSpan: 'xl:col-span-3',
  },
  {
    title: 'All languages.',
    image: allLanguagesImage,
    alt: 'All languages panel showing multilingual communication.',
    desktopSpan: 'xl:col-span-3',
  },
];

const ctaButtonClass =
  'inline-flex items-center justify-center rounded-full px-5 py-3 text-sm font-semibold transition duration-200';

export default function HomePage() {
  return (
    <>
      <Seo />

      <div className="bg-[linear-gradient(180deg,#f8fbff_0%,#ffffff_30%,#f6f8fc_100%)] text-slate-900">
        <section className="pb-8 pt-4 sm:pb-10 sm:pt-6">
          <div className="container-shell">
            <div className="overflow-hidden rounded-[32px] border border-slate-200/80 bg-white shadow-[0_30px_90px_rgba(15,23,42,0.08)]">
              <img
                src={heroImage}
                alt="WTYJ hero panel showing all messages in one inbox across channels."
                className="block h-auto w-full"
                loading="eager"
              />
            </div>
          </div>
        </section>

        <section className="pb-12 pt-4 sm:pb-16">
          <div className="container-shell">
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-6">
              {supportCards.map((card) => (
                <article
                  key={card.title}
                  className={`overflow-hidden rounded-[28px] border border-slate-200/80 bg-white shadow-[0_20px_60px_rgba(15,23,42,0.06)] ${card.desktopSpan}`}
                >
                  <img src={card.image} alt={card.alt} className="block h-auto w-full" loading="lazy" />
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="pb-10 pt-4 sm:pb-14">
          <div className="container-shell">
            <div className="mx-auto max-w-4xl text-center">
              <p className="text-sm font-semibold uppercase tracking-[0.28em] text-blue-600">
                More time for what matters
              </p>
              <h1 className="mt-5 text-4xl font-semibold tracking-[-0.04em] text-slate-950 sm:text-5xl lg:text-6xl">
                More time. More clients. More life.
              </h1>
              <p className="mx-auto mt-5 max-w-3xl text-lg leading-8 text-slate-600 sm:text-xl">
                All your messages. 1 Inbox. More time for what matters.
              </p>
              <p className="mx-auto mt-4 max-w-3xl text-base leading-7 text-slate-500">
                Less busywork. More business. Faster replies. Smart automation. Human oversight.
              </p>
            </div>
          </div>
        </section>

        <section className="pb-24 pt-4 sm:pb-28">
          <div className="container-shell">
            <div className="rounded-[32px] border border-slate-200/80 bg-white px-6 py-10 text-center shadow-[0_24px_80px_rgba(15,23,42,0.08)] sm:px-10 sm:py-14">
              <p className="text-sm font-semibold uppercase tracking-[0.28em] text-slate-500">
                Ready when you are
              </p>
              <h2 className="mt-4 text-3xl font-semibold tracking-[-0.03em] text-slate-950 sm:text-4xl">
                One inbox across channels. One team in control.
              </h2>
              <p className="mx-auto mt-4 max-w-2xl text-base leading-7 text-slate-600 sm:text-lg">
                Give your team faster replies, calmer workflows, and more space to focus on the work
                that actually grows the business.
              </p>
              <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
                <Link
                  to="/contact"
                  className={`${ctaButtonClass} bg-[linear-gradient(135deg,#2563eb_0%,#3b82f6_55%,#60a5fa_100%)] text-white shadow-[0_18px_40px_rgba(37,99,235,0.28)] hover:-translate-y-0.5 hover:shadow-[0_24px_44px_rgba(37,99,235,0.34)]`}
                >
                  Get started
                </Link>
                <Link
                  to="/services"
                  className={`${ctaButtonClass} border border-slate-200 bg-slate-50 text-slate-900 hover:border-slate-300 hover:bg-white`}
                >
                  See how it works
                </Link>
              </div>
            </div>
          </div>
        </section>
      </div>
    </>
  );
}
