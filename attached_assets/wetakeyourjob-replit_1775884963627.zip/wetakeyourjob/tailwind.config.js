/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        night: '#050b14',
        ink: '#0b1422',
        panel: '#111d30',
        line: 'rgba(148, 163, 184, 0.18)',
        glow: '#36d1ff',
        teal: '#2dd4bf',
      },
      boxShadow: {
        soft: '0 18px 60px rgba(4, 12, 24, 0.45)',
        panel: '0 12px 40px rgba(4, 12, 24, 0.34)',
      },
      backgroundImage: {
        'hero-grid':
          'linear-gradient(rgba(148,163,184,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(148,163,184,0.08) 1px, transparent 1px)',
      },
      fontFamily: {
        sans: ['"Sora"', 'ui-sans-serif', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
