import InfoCard from './InfoCard';

export default function ServiceCard(props) {
  return <InfoCard {...props} className="hover:border-glow/30 hover:bg-white/[0.05]" />;
}
