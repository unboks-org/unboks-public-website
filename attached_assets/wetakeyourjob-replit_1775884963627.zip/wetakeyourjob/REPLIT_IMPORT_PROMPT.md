# Replit Import Prompt

Use this prompt in Replit after uploading the zip:

```md
This is a complete React + Vite + Tailwind CSS marketing website for wetakeyourjob.com.

Project requirements:
- Keep the project as a frontend-only site
- Use React + Vite + Tailwind CSS
- Do not add a backend
- Do not add CMS, auth, blog, or testimonials
- Preserve the premium dark SaaS visual style
- Keep the existing routing:
  - /
  - /services
  - /about
  - /contact
- Keep the positioning:
  - AI tools that save time
  - remove repetitive communication work
  - human + AI symbiosis
  - humans stay in control
  - managers get dashboard oversight
  - teams become more productive
- Do not shift the messaging into “AI replaces the whole team”
- Do not turn it into generic CRM or chatbot-only language

What to do:
1. Install dependencies with `npm install`
2. Run the development server with `npm run dev`
3. If needed, expose the Vite app correctly in Replit preview
4. Keep the folder structure clean and maintainable
5. Preserve and improve the current design system rather than replacing it with a generic template

Success criteria:
- Project runs immediately
- Styling renders correctly
- All routes work
- Responsive on mobile/tablet/desktop
- Premium, polished SaaS-quality UI remains intact
```

## Local run commands

```bash
npm install
npm run dev
```

## Build command

```bash
npm run build
```
