export type Lang = 'pap' | 'en' | 'es' | 'nl' | 'sv';

export const LANGUAGES: { code: Lang; label: string; flag: string }[] = [
  { code: 'pap', label: 'Papiamentu', flag: '🇨🇼' },
  { code: 'en',  label: 'English',    flag: '🇬🇧' },
  { code: 'es',  label: 'Español',    flag: '🇪🇸' },
  { code: 'nl',  label: 'Nederlands', flag: '🇳🇱' },
  { code: 'sv',  label: 'Svenska',    flag: '🇸🇪' },
];

export const t: Record<Lang, Record<string, string>> = {
  pap: {
    nav_services:   'Loke nos ta hasi',
    nav_how:        'Asina ta funshoná',
    nav_contact:    'Kontakto',
    nav_login:      'Drenta',
    nav_cta:        'Kuminsá',

    hero_tag:       'AI pa bo mensahenan',
    hero_h1a:       'Tur bo mensahenan.',
    hero_h1b:       'Un inbox.',
    hero_p:         'Un solo lugá pa tur bo mensahenan. Di WhatsApp te na e-mail i socials, AI ta yuda ku kontesta, ordená i manda e mensahe pa e persona korekto.',
    hero_cta:       'Kuminsá',
    hero_see:       'Mira kon ta funshoná',

    channels_label: 'Kanalnan',

    feat_label:     'Loke nos ta kita for di bo man',
    feat_title:     'Menos trabou rutinario. Mas tempu.',
    feat_sub:       'Unboks ta yuda ku e trabou di mensahe ku ta bolbe tur dia: kontesta pregunta, sigui sita, rekonosé òrden, informá klientenan i manda mensahenan importante pa e persona korekto.\n\nBo ta mira solamente loke realmente mester atenshon: eskalashonnan, òrdennan i sitanan buká.',

    how_label:      'Asina nos ta duna bo tempu bèk',
    how_title:      'Menos strès di mensahe. Mas tempu pa bo trabou real.',
    how_sub:        'Tur kos ta bin huntu den un inbox. AI ta hasi loke e por hasi i ta avisá bo ora algu mester bo atenshon. Asina bo komunikashon ta sigui kore 24/7, den varios idioma, mientras bo ta mira solamente loke mester atenshon.',
    step1_title:    'Nos ta wak unda bo ta pèrdè tempu',
    step1_p:        'Den un kòmbersashon kòrtiku nos ta mira unda mas mensahenan ta drenta, kua preguntanan ta bolbe i unda AI por yuda ku siguridat.',
    step2_title:    'Nos ta konfigurá Unboks pa bo',
    step2_p:        'Nos ta konektá bo kanalnan, agregá bo informashon i pone regla pa kontesta, ordená, sigui i manda mensahenan pa e persona korekto.',
    step3_title:    'Bo ta keda na kontrol',
    step3_p:        'AI ta hasi loke e por hasi. Tur kos ku ta importante, poko kla of sensibel ta yega serka bo of e persona korekto.',

    out_label:      'Loke bo ta haña',
    out_title_a:    'Mas tempu.',
    out_title_b:    'Mas bista.',
    out_title_c:    'Menos stress.',
    out1:           'Menos kontesta manual',
    out2:           'Kontesta mas lihé riba tur bo kanalnan',
    out3:           'Tur mensahenan kla i ordená den un lugá',
    out4:           'Kosnan importante direktamente serka e persona korekto',

    stat_label:     'Den sifra',
    stat1_lbl:      'Kanalnan den un inbox',
    stat2_lbl:      'Semper disponibel',
    stat3_lbl:      'Kontesta mas lihé',
    stat4_lbl:      'Menos mensahenan pèrdí',

    cta_h2:         'Haña bo dia bèk.',
    cta_p:          'Mustra nos unda bo mensahenan ta drenta i unda bo ta pèrdè tempu. Nos ta mustra bo kon Unboks ta kita e trabou ei for di bo man.',
    cta_book:       'Buká un yamada',

    footer_sub:     'AI pa mensahenan, seguimiento i bista general.',
    footer_email:   'hello@unboks.org',
  },

  en: {
    nav_services:   'What we do',
    nav_how:        'How it works',
    nav_contact:    'Contact',
    nav_login:      'Log in',
    nav_cta:        'Get started',

    hero_tag:       'AI for your messages',
    hero_h1a:       'All your messages.',
    hero_h1b:       'One inbox.',
    hero_p:         'One place for all your messages. From WhatsApp to email and socials, AI helps answer, sort, and send messages to the right person.',
    hero_cta:       'Get started',
    hero_see:       'See how it works',

    channels_label: 'Channels',

    feat_label:     'What we take off your hands',
    feat_title:     'Less routine work. More time.',
    feat_sub:       'Unboks helps with the message work that comes back every day: answering questions, following up on appointments, recognizing orders, informing customers, and forwarding important messages.\n\nYou only see what really needs attention: escalations, orders, and booked appointments.',

    how_label:      'How we give you time back',
    how_title:      'Less message stress. More time for your real work.',
    how_sub:        'Everything comes together in one inbox. AI handles what it can and alerts you when something needs your attention. Your communication keeps running 24/7, in multiple languages, while you only see what needs attention.',
    step1_title:    'We find where you lose time',
    step1_p:        'In a short call, we map where most messages come in, which questions keep coming back, and where AI can safely help.',
    step2_title:    'We set up Unboks for you',
    step2_p:        'We connect your channels, add your information, and set rules for answering, sorting, following up, and forwarding messages.',
    step3_title:    'You stay in control',
    step3_p:        'AI handles what it can. Anything important, unclear, or sensitive goes to you or the right person.',

    out_label:      'What you get',
    out_title_a:    'More time.',
    out_title_b:    'More overview.',
    out_title_c:    'Less hassle.',
    out1:           'Less manual reply work',
    out2:           'Faster replies across all your channels',
    out3:           'All messages clearly organized in one place',
    out4:           'Important matters sent straight to the right person',

    stat_label:     'By the numbers',
    stat1_lbl:      'Channels in one inbox',
    stat2_lbl:      'Always reachable',
    stat3_lbl:      'Faster replies',
    stat4_lbl:      'Fewer missed messages',

    cta_h2:         'Get your day back.',
    cta_p:          'Show us where your messages come in and where you lose time. We\'ll show you how Unboks takes that work off your hands.',
    cta_book:       'Book a call',

    footer_sub:     'AI for messages, follow-up, and overview.',
    footer_email:   'hello@unboks.org',
  },

  es: {
    nav_services:   'Qué hacemos',
    nav_how:        'Cómo funciona',
    nav_contact:    'Contacto',
    nav_login:      'Iniciar sesión',
    nav_cta:        'Empezar',

    hero_tag:       'IA para tus mensajes',
    hero_h1a:       'Todos tus mensajes.',
    hero_h1b:       'Una bandeja.',
    hero_p:         'Un solo lugar para todos tus mensajes. Desde WhatsApp hasta email y redes sociales, la IA ayuda a responder, ordenar y enviar cada mensaje a la persona correcta.',
    hero_cta:       'Empezar',
    hero_see:       'Ver cómo funciona',

    channels_label: 'Canales',

    feat_label:     'Lo que te quitamos de encima',
    feat_title:     'Menos trabajo rutinario. Más tiempo.',
    feat_sub:       'Unboks ayuda con el trabajo de mensajes que vuelve todos los días: responder preguntas, dar seguimiento a citas, reconocer pedidos, informar a clientes y reenviar mensajes importantes.\n\nTú solo ves lo que realmente necesita atención: escalaciones, pedidos y citas reservadas.',

    how_label:      'Así te devolvemos tiempo',
    how_title:      'Menos estrés de mensajes. Más tiempo para tu trabajo real.',
    how_sub:        'Todo llega a una sola bandeja. La IA se encarga de lo que puede y te avisa cuando algo necesita tu atención. Tu comunicación sigue funcionando 24/7, en varios idiomas, mientras tú solo ves lo que necesita atención.',
    step1_title:    'Vemos dónde pierdes tiempo',
    step1_p:        'En una llamada corta vemos dónde llegan más mensajes, qué preguntas se repiten y dónde la IA puede ayudar de forma segura.',
    step2_title:    'Configuramos Unboks para ti',
    step2_p:        'Conectamos tus canales, agregamos tu información y configuramos reglas para responder, ordenar, hacer seguimiento y reenviar mensajes.',
    step3_title:    'Tú mantienes el control',
    step3_p:        'La IA se encarga de lo que puede. Todo lo importante, poco claro o sensible llega a ti o a la persona correcta.',

    out_label:      'Lo que obtienes',
    out_title_a:    'Más tiempo.',
    out_title_b:    'Más claridad.',
    out_title_c:    'Menos lío.',
    out1:           'Menos trabajo manual respondiendo mensajes',
    out2:           'Respuestas más rápidas en todos tus canales',
    out3:           'Todos los mensajes ordenados en un solo lugar',
    out4:           'Los asuntos importantes llegan directo a la persona correcta',

    stat_label:     'En números',
    stat1_lbl:      'Canales en una bandeja',
    stat2_lbl:      'Siempre disponible',
    stat3_lbl:      'Respuestas más rápidas',
    stat4_lbl:      'Menos mensajes perdidos',

    cta_h2:         'Recupera tu día.',
    cta_p:          'Muéstranos dónde llegan tus mensajes y dónde pierdes tiempo. Te mostramos cómo Unboks se encarga de ese trabajo.',
    cta_book:       'Reservar una llamada',

    footer_sub:     'IA para mensajes, seguimiento y control.',
    footer_email:   'hello@unboks.org',
  },

  nl: {
    nav_services:   'Wat we doen',
    nav_how:        'Zo werkt het',
    nav_contact:    'Contact',
    nav_login:      'Inloggen',
    nav_cta:        'Aan de slag',

    hero_tag:       'AI voor je berichten',
    hero_h1a:       'Al je berichten.',
    hero_h1b:       'Één inbox.',
    hero_p:         'Eén plek voor al je berichten. Van WhatsApp tot e-mail en socials, AI helpt met antwoorden, sorteren en doorzetten naar de juiste persoon.',
    hero_cta:       'Aan de slag',
    hero_see:       'Bekijk hoe het werkt',

    channels_label: 'Kanalen',

    feat_label:     'Wat wij uit handen nemen',
    feat_title:     'Minder routinewerk. Meer tijd.',
    feat_sub:       'Unboks helpt met het berichtenwerk dat elke dag terugkomt: vragen beantwoorden, afspraken opvolgen, orders herkennen, klanten informeren en belangrijke berichten doorzetten.\n\nJe ziet alleen wat echt aandacht nodig heeft: escalaties, orders en geboekte afspraken.',

    how_label:      'Zo geven we je tijd terug',
    how_title:      'Minder berichtenstress. Meer tijd voor je echte werk.',
    how_sub:        'Alles komt samen in één inbox. AI handelt af wat kan en waarschuwt je wanneer iets jouw aandacht nodig heeft. Zo blijft je communicatie 24/7 doorlopen, in meerdere talen, terwijl jij alleen ziet wat aandacht nodig heeft.',
    step1_title:    'We kijken waar je tijd verliest',
    step1_p:        'In een kort gesprek brengen we in kaart waar de meeste berichten binnenkomen, welke vragen steeds terugkomen en waar AI veilig kan helpen.',
    step2_title:    'We richten Unboks voor je in',
    step2_p:        'We koppelen je kanalen, voegen je informatie toe en stellen regels in voor antwoorden, sorteren, opvolgen en doorzetten.',
    step3_title:    'Jij blijft in controle',
    step3_p:        'AI handelt af wat kan. Alles wat belangrijk, onduidelijk of gevoelig is, komt bij jou of de juiste persoon terecht.',

    out_label:      'Wat je krijgt',
    out_title_a:    'Meer tijd.',
    out_title_b:    'Meer overzicht.',
    out_title_c:    'Minder gedoe.',
    out1:           'Minder handmatig antwoordwerk',
    out2:           'Snellere reacties via al je kanalen',
    out3:           'Alle berichten overzichtelijk op één plek',
    out4:           'Belangrijke zaken direct bij de juiste persoon',

    stat_label:     'In cijfers',
    stat1_lbl:      'Kanalen in één inbox',
    stat2_lbl:      'Altijd bereikbaar',
    stat3_lbl:      'Snellere reacties',
    stat4_lbl:      'Minder gemiste berichten',

    cta_h2:         'Krijg je dag terug.',
    cta_p:          'Laat ons zien waar je berichten binnenkomen en waar je tijd verliest. Dan laten wij zien hoe Unboks dat werk uit handen neemt.',
    cta_book:       'Plan een kort gesprek',

    footer_sub:     'AI voor berichten, opvolging en overzicht.',
    footer_email:   'hello@unboks.org',
  },

  sv: {
    nav_services:   'Vad vi gör',
    nav_how:        'Så fungerar det',
    nav_contact:    'Kontakt',
    nav_login:      'Logga in',
    nav_cta:        'Kom igång',

    hero_tag:       'AI för dina meddelanden',
    hero_h1a:       'Alla dina meddelanden.',
    hero_h1b:       'En inkorg.',
    hero_p:         'En plats för alla dina meddelanden. Från WhatsApp till e-post och sociala medier hjälper AI till att svara, sortera och skicka vidare till rätt person.',
    hero_cta:       'Kom igång',
    hero_see:       'Se hur det fungerar',

    channels_label: 'Kanaler',

    feat_label:     'Det vi tar hand om',
    feat_title:     'Mindre rutinjobb. Mer tid.',
    feat_sub:       'Unboks hjälper till med meddelandearbetet som kommer tillbaka varje dag: svara på frågor, följa upp bokningar, känna igen beställningar, informera kunder och skicka viktiga meddelanden vidare.\n\nDu ser bara det som verkligen behöver uppmärksamhet: eskaleringar, beställningar och bokade tider.',

    how_label:      'Så ger vi dig tid tillbaka',
    how_title:      'Mindre meddelandestress. Mer tid för ditt riktiga arbete.',
    how_sub:        'Allt samlas i en inkorg. AI hanterar det den kan och varnar dig när något behöver din uppmärksamhet. Din kommunikation fortsätter 24/7, på flera språk, medan du bara ser det som behöver uppmärksamhet.',
    step1_title:    'Vi ser var du förlorar tid',
    step1_p:        'I ett kort samtal går vi igenom var flest meddelanden kommer in, vilka frågor som återkommer och var AI kan hjälpa till på ett säkert sätt.',
    step2_title:    'Vi ställer in Unboks åt dig',
    step2_p:        'Vi kopplar dina kanaler, lägger till din information och sätter regler för svar, sortering, uppföljning och vidarebefordran.',
    step3_title:    'Du behåller kontrollen',
    step3_p:        'AI hanterar det den kan. Allt som är viktigt, oklart eller känsligt går till dig eller rätt person.',

    out_label:      'Det du får',
    out_title_a:    'Mer tid.',
    out_title_b:    'Bättre överblick.',
    out_title_c:    'Mindre krångel.',
    out1:           'Mindre manuellt svarsarbete',
    out2:           'Snabbare svar i alla dina kanaler',
    out3:           'Alla meddelanden tydligt samlade på en plats',
    out4:           'Viktiga saker direkt till rätt person',

    stat_label:     'I siffror',
    stat1_lbl:      'Kanaler i en inkorg',
    stat2_lbl:      'Alltid nåbar',
    stat3_lbl:      'Snabbare svar',
    stat4_lbl:      'Färre missade meddelanden',

    cta_h2:         'Ta tillbaka din dag.',
    cta_p:          'Visa oss var dina meddelanden kommer in och var du förlorar tid. Vi visar hur Unboks tar det arbetet från dina händer.',
    cta_book:       'Boka ett samtal',

    footer_sub:     'AI för meddelanden, uppföljning och överblick.',
    footer_email:   'hello@unboks.org',
  },
};