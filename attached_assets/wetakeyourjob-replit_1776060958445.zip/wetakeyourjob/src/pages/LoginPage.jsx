import { Link } from 'react-router-dom';
import Seo from '../components/Seo';

export default function LoginPage() {
  return (
    <>
      <Seo
        title="Login"
        description="Client login access for We Take Your Job."
      />

      <div className="bg-[linear-gradient(180deg,#f8fbff_0%,#ffffff_35%,#f6f8fc_100%)] py-20 sm:py-24">
        <div className="container-shell">
          <div className="mx-auto max-w-2xl rounded-[32px] border border-slate-200/80 bg-white px-6 py-10 text-center shadow-[0_24px_80px_rgba(15,23,42,0.08)] sm:px-10 sm:py-14">
            <p className="text-sm font-semibold uppercase tracking-[0.28em] text-blue-600">
              Client access
            </p>
            <h1 className="mt-4 text-4xl font-semibold tracking-[-0.04em] text-slate-950">
              Login access is handled directly with clients.
            </h1>
            <p className="mx-auto mt-4 max-w-xl text-base leading-7 text-slate-600">
              If you need access to your inbox or control dashboard, contact the WTYJ team and
              we&apos;ll point you to the right login flow.
            </p>
            <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <Link
                to="/contact"
                className="inline-flex items-center justify-center rounded-full bg-[linear-gradient(135deg,#2563eb_0%,#3b82f6_55%,#60a5fa_100%)] px-5 py-3 text-sm font-semibold text-white shadow-[0_18px_40px_rgba(37,99,235,0.28)] transition duration-200 hover:-translate-y-0.5 hover:shadow-[0_24px_44px_rgba(37,99,235,0.34)]"
              >
                Contact us
              </Link>
              <Link
                to="/"
                className="inline-flex items-center justify-center rounded-full border border-slate-200 bg-slate-50 px-5 py-3 text-sm font-semibold text-slate-900 transition duration-200 hover:border-slate-300 hover:bg-white"
              >
                Back home
              </Link>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
