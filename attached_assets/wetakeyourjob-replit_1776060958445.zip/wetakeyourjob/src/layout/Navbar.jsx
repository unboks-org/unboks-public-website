import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import { NavLink, useLocation } from 'react-router-dom';

const navItems = [
  { label: 'Services', href: '/services' },
  { label: 'About', href: '/about' },
  { label: 'Contact', href: '/contact' },
  { label: 'Login', href: '/login' },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);
  const location = useLocation();

  const closeMenu = () => setOpen(false);

  return (
    <header className="sticky top-0 z-50 border-b border-slate-200/80 bg-white/88 backdrop-blur-xl">
      <div className="container-shell flex h-20 items-center justify-between gap-6">
        <NavLink
          to="/"
          className="text-lg font-semibold tracking-tight text-slate-950"
          onClick={closeMenu}
        >
          WTYJ
        </NavLink>

        <nav className="hidden items-center gap-2 md:flex">
          {navItems.map((link) => (
            <NavLink
              key={link.href}
              to={link.href}
              className={({ isActive }) =>
                `rounded-full px-4 py-2 text-sm font-medium ${
                  isActive
                    ? 'bg-slate-100 text-slate-950'
                    : 'text-slate-600 hover:bg-slate-100/80 hover:text-slate-950'
                }`
              }
            >
              {link.label}
            </NavLink>
          ))}
        </nav>

        <NavLink
          to="/contact"
          className="hidden rounded-full bg-[linear-gradient(135deg,#2563eb_0%,#3b82f6_55%,#60a5fa_100%)] px-5 py-3 text-sm font-semibold text-white shadow-[0_14px_32px_rgba(37,99,235,0.24)] transition duration-200 hover:-translate-y-0.5 hover:shadow-[0_18px_36px_rgba(37,99,235,0.3)] md:inline-flex"
        >
          Get started
        </NavLink>

        <button
          type="button"
          className="inline-flex rounded-full border border-slate-200 bg-white p-3 text-slate-900 md:hidden"
          onClick={() => setOpen((value) => !value)}
          aria-expanded={open}
          aria-label={open ? 'Close menu' : 'Open menu'}
        >
          {open ? <X size={18} /> : <Menu size={18} />}
        </button>
      </div>

      {open ? (
        <div className="border-t border-slate-200 bg-white/95 md:hidden">
          <div className="container-shell flex flex-col gap-2 py-4">
            {navItems.map((link) => {
              const active = location.pathname === link.href;
              return (
                <NavLink
                  key={link.href}
                  to={link.href}
                  onClick={closeMenu}
                  className={`rounded-2xl px-4 py-3 text-sm font-medium ${
                    active ? 'bg-slate-100 text-slate-950' : 'text-slate-700'
                  }`}
                >
                  {link.label}
                </NavLink>
              );
            })}
            <NavLink
              to="/contact"
              onClick={closeMenu}
              className="mt-2 inline-flex w-full items-center justify-center rounded-full bg-[linear-gradient(135deg,#2563eb_0%,#3b82f6_55%,#60a5fa_100%)] px-5 py-3 text-sm font-semibold text-white"
            >
              Get started
            </NavLink>
          </div>
        </div>
      ) : null}
    </header>
  );
}
